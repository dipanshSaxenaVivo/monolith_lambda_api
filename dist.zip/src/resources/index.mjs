import {
  responseErrorMessage
} from "../chunks/chunk-VNKQ4MGN.mjs";
export {
  responseErrorMessage
};
