import {
  routeContainer_default
} from "./chunks/chunk-KMWZH3BR.mjs";
import "./chunks/chunk-I5NGJBO2.mjs";
import {
  applyConsoleLogger,
  applyKms,
  applyPrisma
} from "./chunks/chunk-MCJF2Z5M.mjs";
import {
  createStandardError
} from "./chunks/chunk-TQMR533B.mjs";
import "./chunks/chunk-VNKQ4MGN.mjs";

// src/index.ts
var injector = applyKms(applyConsoleLogger({}));
var decryptedEnvString = await injector.cryptography.getEnvironmentVariable(
  "MONGO_DB_URI_ENC"
);
if (decryptedEnvString) {
  injector = applyPrisma(injector, decryptedEnvString);
}
var handler = async (event, context) => {
  injector.logger.log(
    "event object %s,\n context object %O",
    JSON.stringify(event),
    context
  );
  if (!(event.rawPath in routeContainer_default)) {
    return {
      statusCode: 404 /* NOT_FOUND_404 */,
      body: JSON.stringify(createStandardError(3 /* RESOURCE_NOT_FOUND */))
    };
  }
  try {
    const routeHandler = routeContainer_default[event.rawPath];
    const result = await routeHandler(injector, event, context);
    return result;
  } catch (error) {
    injector.logger.log(error, JSON.stringify(error));
    return {
      statusCode: 500 /* INTERNAL_SERVER_ERROR_500 */,
      body: JSON.stringify(createStandardError(2 /* INTERNAL_SERVER_ERROR */))
    };
  }
};
export {
  handler
};
