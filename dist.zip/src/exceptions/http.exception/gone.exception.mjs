import {
  HttpException
} from "../../chunks/chunk-ZIZLTV45.mjs";
import {
  createStandardError
} from "../../chunks/chunk-TQMR533B.mjs";
import "../../chunks/chunk-VNKQ4MGN.mjs";

// src/exceptions/http.exception/gone.exception.ts
var GoneException = class extends HttpException {
  /**
   * Instantiate a `GoneException` Exception.
   *
   * @example
   * `throw new GoneException(ResponseCodeEnum.SOME_ERROR_CODE)`
   *
   * @usageNotes
   * The HTTP response status code will be 410.
   * 
   * The response will contain a standard error object created based on the provided response code.
   *
   * @param {ResponseCodeEnum} responseCode - Enum value representing the error code.
   * @param {string[]} [extra] - Optional additional error details.
   */
  constructor(responseCode, extra) {
    let ErrorObject = createStandardError(responseCode, extra);
    super(
      ErrorObject,
      410 /* GONE_410 */
    );
  }
};
export {
  GoneException
};
