import {
  HttpException
} from "../../chunks/chunk-ZIZLTV45.mjs";
import {
  createStandardError
} from "../../chunks/chunk-TQMR533B.mjs";
import "../../chunks/chunk-VNKQ4MGN.mjs";

// src/exceptions/http.exception/bad-request.exception.ts
var BadRequestException = class extends HttpException {
  /**
   * Instantiate a `BadRequestException` Exception.
   *
   * @example
   * `throw new BadRequestException(ResponseCodeEnum.INVALID_INPUT)`
   *
   * @usageNotes
   * The HTTP response status code will be 400.
   *
   * The response will contain a standard error object created based on the provided response code.
   *
   * @param {ResponseCodeEnum} responseCode - Enum value representing the error code.
   * @param {string[]} [extra] - Optional additional error details.
   */
  constructor(responseCode, extra) {
    const ErrorObject = createStandardError(responseCode, extra);
    super(
      ErrorObject,
      400 /* BAD_REQUEST_400 */
    );
  }
};
export {
  BadRequestException
};
