import {
  HttpException
} from "../../chunks/chunk-ZIZLTV45.mjs";
import {
  createStandardError
} from "../../chunks/chunk-TQMR533B.mjs";
import "../../chunks/chunk-VNKQ4MGN.mjs";

// src/exceptions/http.exception/conflict.exception.ts
var ConflictException = class extends HttpException {
  /**
   * Instantiate a `ConflictException` Exception.
   *
   * @example
   * `throw new ConflictException(ResponseCodeEnum.ALREADY_EXIST)`
   *
   * @usageNotes
   * The HTTP response status code will be 409.
   * 
   * The response will contain a standard error object created based on the provided response code.
   *
   * @param {ResponseCodeEnum} responseCode - Enum value representing the error code.
   * @param {string[]} [extra] - Optional additional error details.
   */
  constructor(responseCode, extra) {
    let ErrorObject = createStandardError(responseCode, extra);
    super(
      ErrorObject,
      409 /* CONFLICT_409 */
    );
  }
};
export {
  ConflictException
};
