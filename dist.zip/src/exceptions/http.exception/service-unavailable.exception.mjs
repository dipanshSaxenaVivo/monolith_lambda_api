import {
  HttpException
} from "../../chunks/chunk-ZIZLTV45.mjs";
import {
  createStandardError
} from "../../chunks/chunk-TQMR533B.mjs";
import "../../chunks/chunk-VNKQ4MGN.mjs";

// src/exceptions/http.exception/service-unavailable.exception.ts
var ServiceUnavailableException = class extends HttpException {
  /**
   * Instantiate a `ServiceUnavailableException` Exception.
   *
   * @example
   * `throw new ServiceUnavailableException(ResponseCodeEnum.SOME_ERROR_CODE)`
   *
   * @usageNotes
   * The HTTP response status code will be 503.
   * 
   * The response will contain a standard error object created based on the provided response code.
   *
   * @param {ResponseCodeEnum} responseCode - Enum value representing the error code.
   * @param {string[]} [extra] - Optional additional error details.
   */
  constructor(responseCode, extra) {
    let ErrorObject = createStandardError(responseCode, extra);
    super(
      ErrorObject,
      503 /* SERVICE_UNAVAILABLE_503 */
    );
  }
};
export {
  ServiceUnavailableException
};
