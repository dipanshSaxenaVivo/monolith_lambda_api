import {
  HttpException
} from "../../chunks/chunk-ZIZLTV45.mjs";
import {
  createStandardError
} from "../../chunks/chunk-TQMR533B.mjs";
import "../../chunks/chunk-VNKQ4MGN.mjs";

// src/exceptions/http.exception/method-not-allowed.exception.ts
var MethodNotAllowedException = class extends HttpException {
  /**
   * Instantiate a `MethodNotAllowedException` Exception.
   *
   * @example
   * `throw new MethodNotAllowedException(ResponseCodeEnum.SOME_ERROR_CODE)`
   *
   * @usageNotes
   * The HTTP response status code will be 405.
   * 
   * The response will contain a standard error object created based on the provided response code.
   *
   * @param {ResponseCodeEnum} responseCode - Enum value representing the error code.
   * @param {string[]} [extra] - Optional additional error details.
   */
  constructor(responseCode, extra) {
    let ErrorObject = createStandardError(responseCode, extra);
    super(
      ErrorObject,
      405 /* METHOD_NOT_ALLOWED_405 */
    );
  }
};
export {
  MethodNotAllowedException
};
