import {
  addUserHandler,
  deleteUserHandler,
  updateUserHandler
} from "./chunk-I5NGJBO2.mjs";
import {
  attachHandler
} from "./chunk-TQMR533B.mjs";

// src/routes/routeContainer.ts
var ROUTE_CONTAINER = {
  "/test/user/add": attachHandler(addUserHandler),
  "/test/user/delete": attachHandler(deleteUserHandler),
  "/test/user/update": attachHandler(updateUserHandler)
};
var routeContainer_default = ROUTE_CONTAINER;

export {
  routeContainer_default
};
