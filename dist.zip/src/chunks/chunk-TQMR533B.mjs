import {
  responseErrorMessage
} from "./chunk-VNKQ4MGN.mjs";

// src/utility/common.ts
function hasRequiredFields(obj, ...fields) {
  const flatFields = fields.flat();
  return flatFields.reduce((acc, current) => {
    if (obj.hasOwnProperty(current)) {
      return acc;
    } else {
      acc.push(current);
      return acc;
    }
  }, []);
}
var getAllKeysFromEnum = (enumObject) => {
  return Object.values(enumObject).filter((value) => typeof value === "number");
};

// src/utility/createStandardError.ts
var createStandardError = (responseCode, extra) => ({
  message: responseErrorMessage[responseCode],
  responseCode,
  extra
});

// src/utility/attachHandler.ts
var attachHandler = (businessHandler) => async (DC, event, context) => {
  let parsedBody = JSON.parse(event.body ?? "{}");
  let result = await businessHandler(DC, parsedBody);
  if (!result.success) {
    return {
      statusCode: 400 /* BAD_REQUEST_400 */,
      body: JSON.stringify(result.data)
    };
  }
  return {
    statusCode: 200 /* OK_200 */,
    body: JSON.stringify(result.data)
  };
};

export {
  hasRequiredFields,
  getAllKeysFromEnum,
  createStandardError,
  attachHandler
};
