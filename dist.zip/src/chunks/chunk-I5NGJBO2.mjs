import {
  createStandardError,
  hasRequiredFields
} from "./chunk-TQMR533B.mjs";

// src/models/businessContracts/foundation.ts
var CreateSuccess = (data) => ({ success: true, data });
var CreateFailure = (data) => ({ success: false, data });

// src/handlers/addUserHandler/validateAddUserRequest.ts
var validateAddUserRequest = async (user, Prisma) => {
  const notAvailableFields = hasRequiredFields(user, "email", "name", "role");
  if (notAvailableFields.length > 0) {
    return CreateFailure(
      createStandardError(
        16 /* REQUIRED_FIELDS_NOT_GIVEN */,
        notAvailableFields
      )
    );
  }
  let userCount = await Prisma.users.count({
    where: {
      email: user.email,
      phoneNumber: user.phoneNumber ?? ""
    }
  });
  let doesUserExist = userCount > 0;
  if (doesUserExist) {
    return CreateFailure(
      createStandardError(14 /* USER_ALREADY_EXIST */)
    );
  }
  return CreateSuccess(user);
};

// src/handlers/addUserHandler/addUser.ts
var addUser = async (user, Prisma) => {
  let result = await Prisma.users.create({
    data: {
      email: user.email && user.email,
      name: user.name && user.name,
      role: user.role,
      phoneNumber: user.phoneNumber && user.phoneNumber
    }
  });
  return result;
};

// src/handlers/addUserHandler/index.ts
var addUserHandler = async (DC, userToAdd) => {
  let validationResult = await validateAddUserRequest(userToAdd, DC.db_client);
  if (!validationResult.success) {
    return CreateFailure(validationResult.data);
  }
  let addedUser = await addUser(validationResult.data, DC.db_client);
  return CreateSuccess(addedUser);
};

// src/handlers/updateUserHandler/validateUpdateUserRequest.ts
var validateUpdateUserRequest = async (user, Prisma) => {
  const notAvailableFields = hasRequiredFields(user, "id");
  if (notAvailableFields.length > 0) {
    return CreateFailure(createStandardError(13 /* ID_IS_REQUIRED */));
  }
  let doesUserExist = await Prisma.users.findUnique({
    where: {
      id: user.id
    }
  });
  if (!Boolean(doesUserExist)) {
    return CreateFailure(
      createStandardError(15 /* USER_ID_NOT_EXIST */)
    );
  }
  return CreateSuccess(user);
};

// src/handlers/updateUserHandler/updateUser.ts
var updateUser = async (user, Prisma) => {
  let { id, ...restData } = user;
  const result = await Prisma.users.update({
    where: {
      id
    },
    data: {
      email: restData.email && restData.email,
      name: restData.name && restData.name,
      phoneNumber: restData?.phoneNumber && restData.phoneNumber,
      role: restData.role && restData.role
    }
  });
  return result;
};

// src/handlers/updateUserHandler/index.ts
var updateUserHandler = async (DC, userData) => {
  let validationResult = await validateUpdateUserRequest(
    userData,
    DC.db_client
  );
  if (validationResult.success === false) {
    return CreateFailure(validationResult.data);
  }
  let updatedUser = await updateUser(userData, DC.db_client);
  return CreateSuccess(updatedUser);
};

// src/handlers/deleteUserHandler/validateDeleteUserRequest.ts
var validateDeleteUserRequest = async (userID, Prisma) => {
  const notAvailableFields = hasRequiredFields(userID, "id");
  if (notAvailableFields.length > 0) {
    return CreateFailure(createStandardError(13 /* ID_IS_REQUIRED */));
  }
  let doesUserExist = await Prisma.users.findUnique({
    where: {
      id: userID.id
    }
  });
  if (!Boolean(doesUserExist)) {
    return CreateFailure(
      createStandardError(15 /* USER_ID_NOT_EXIST */)
    );
  }
  return CreateSuccess(userID);
};

// src/handlers/deleteUserHandler/deleteHandler.ts
var deleteUser = async (userID, Prisma) => {
  const result = await Prisma.users.delete({
    where: {
      id: userID.id
    }
  });
  return result;
};

// src/handlers/deleteUserHandler/index.ts
var deleteUserHandler = async (DC, userID) => {
  let validationResult = await validateDeleteUserRequest(userID, DC.db_client);
  if (validationResult.success === false) {
    return CreateFailure(validationResult.data);
  }
  await deleteUser(userID, DC.db_client);
  return CreateSuccess({});
};

export {
  addUserHandler,
  updateUserHandler,
  deleteUserHandler
};
