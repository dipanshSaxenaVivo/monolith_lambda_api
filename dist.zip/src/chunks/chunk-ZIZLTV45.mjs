// src/exceptions/http.exception/index.ts
var HttpException = class extends Error {
  /**
   * Creates an instance of HttpException.
   *
   * @param {IError | undefined} response - The error response object containing error details.
   * @param {number} status - The HTTP status code associated with the error.
   */
  constructor(response, status) {
    super();
    this.response = response;
    this.status = status;
    this.initMessage();
    this.initName();
  }
  /**
   * Initializes the error message based on the response object or class name.
   */
  initMessage() {
    if (this.response && this.response.message) {
      this.message = this.response.message;
    } else if (this.constructor) {
      this.message = this.constructor.name.match(/[A-Z][a-z]+|[0-9]+/g)?.join(" ") ?? "Error";
    }
  }
  /**
   * Initializes the error name based on the class name.
   */
  initName() {
    this.name = this.constructor.name;
  }
  /**
   * Returns the response object associated with the exception.
   *
   * @returns {IError | undefined} The error response object.
   */
  getResponse() {
    return this.response;
  }
  /**
   * Returns the HTTP status code associated with the exception.
   *
   * @returns {number} The HTTP status code.
   */
  getStatus() {
    return this.status;
  }
};

export {
  HttpException
};
