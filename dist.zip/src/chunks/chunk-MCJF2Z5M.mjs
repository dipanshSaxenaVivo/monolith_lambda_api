// src/dependencies/consoleLogUtility.ts
console.log("console log utility");
var log = (...args) => {
  console.log(...args);
};
var error = (...args) => {
  console.error(...args);
};
var info = (...args) => {
  console.info(...args);
};
var warn = (...args) => {
  console.warn(...args);
};
var consoleLogger = {
  log,
  error,
  info,
  warn
};
var applyConsoleLogger = (DC) => {
  return { ...DC, logger: consoleLogger };
};

// src/dependencies/kmsUtility.ts
import { KMS as KMSClient, DecryptCommand, EncryptCommand } from "@aws-sdk/client-kms";
console.log("kms utility");
var kmsModule = new KMSClient();
var decrypt = async (CipherText) => {
  const params = {
    CiphertextBlob: Buffer.from(CipherText, "base64"),
    EncryptionContext: {
      LambdaFunctionName: process.env.AWS_LAMBDA_FUNCTION_NAME || ""
    }
  };
  console.log(params, "encoded");
  try {
    let decrypted;
    let decryptCommand = new DecryptCommand(params);
    const data = await kmsModule.send(decryptCommand);
    console.log(data, decryptCommand, "kms decrypt utility");
    decrypted = data.Plaintext && Buffer.from(data.Plaintext).toString();
    console.log("Decrypted Key:", decrypted);
    return decrypted;
  } catch (error2) {
    console.error("Error decrypting key:", error2);
    throw new Error("Error decrypting key:", { cause: error2 });
  }
};
var DB_KMS_KEY_ID;
if (process.env.DB_KMS_KEY_ID_ENC) {
  DB_KMS_KEY_ID = await decrypt(process.env.DB_KMS_KEY_ID_ENC);
}
var DB_KMS_KEY_ID;
var encrypt = async (data, keyId) => {
  const params = {
    KeyId: keyId || (DB_KMS_KEY_ID ?? ""),
    Plaintext: Buffer.from(data),
    EncryptionContext: {
      LambdaFunctionName: process.env.AWS_LAMBDA_FUNCTION_NAME || ""
    }
  };
  console.log(params, "encoded values");
  try {
    let encryptCommand = new EncryptCommand(params);
    const result = await kmsModule.send(encryptCommand);
    console.log(data, result, "kms encrypt utility");
    let encrypted = Buffer.from(result?.CiphertextBlob).toString("base64");
    console.log(encrypted);
    return encrypted;
  } catch (error2) {
    throw new Error("Error encrypting:", { cause: error2 });
  }
};
var getEnvironmentVariable = (ENV_NAME) => {
  let encryptedBase64Text = process.env[ENV_NAME];
  if (!encryptedBase64Text) {
    throw new Error(`Environment Variable ${ENV_NAME} not found.`);
  } else {
    return decrypt(encryptedBase64Text);
  }
};
var KMS = {
  decrypt,
  encrypt,
  getEnvironmentVariable
};
var applyKms = (DC) => {
  console.log("apply kms called");
  return { ...DC, cryptography: KMS };
};

// src/dependencies/prismaClientUtility.ts
import * as Prisma from "@prisma/client";
console.log("prisma utility");
var applyPrisma = (DC, decryptedEnvString) => {
  let prisma = new Prisma.PrismaClient({
    datasourceUrl: decryptedEnvString
  });
  console.log("prisma client instantiated");
  return { ...DC, db_client: prisma };
};

export {
  applyConsoleLogger,
  applyKms,
  applyPrisma
};
